import React from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import ProductResults from './ProductResults';  // Your results page
import CISLookup from './CISLookup';

const App = () => {
  return (
    <Router>
      <Routes>
        {/* Default Route - Redirects to CIS Interest Rate Calculator */}
        <Route path="/" element={<Navigate to="/cis-calculator" replace />} />

        {/* CIS Interest Rate Calculator page */}
        <Route path="/cis-calculator" element={<CISLookup />} />

        {/* Product results page */}
        <Route path="/results" element={<ProductResults />} />
      </Routes>
    </Router>
  );
};

export default App;
