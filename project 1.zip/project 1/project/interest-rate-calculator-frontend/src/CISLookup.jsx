import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';  // Import useNavigate hook for navigation
import './CISLookup.css';

const CISLookup = () => {
  const [cisNumber, setCisNumber] = useState('');
  const [deathDate, setDeathDate] = useState('');
  const [loading, setLoading] = useState(false);
  const [results, setResults] = useState([]);
  
  const navigate = useNavigate();  // Initialize the navigate function

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    if (name === 'cisNumber') {
      setCisNumber(value);
    } else if (name === 'deathDate') {
      setDeathDate(value);
    }
  };

  const handleSearch = async () => {
    if (!cisNumber || !deathDate) {
      alert('Please enter CIS Number and Date of Death');
      return;
    }

    setLoading(true);

    try {
      const response = await fetch('http://localhost:5000/search', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          cisNumber: cisNumber,
          dateOfDeath: deathDate,
        }),
      });

      if (!response.ok) {
        throw new Error('CIS Number not found');
      }

      const data = await response.json();

      console.log("Data received:", data); // Log the data here to ensure it has interestRatesHistory

      setResults(data.products);

      navigate('/results', { state: { results: data.products } });

    } catch (error) {
      alert(error.message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="page-container">
      <h2>Locate Customer</h2>
      <div className="form-section">
        <label htmlFor="cisNumber">CIS Number:</label>
        <input
          type="text"
          name="cisNumber"
          id="cisNumber"
          value={cisNumber}
          onChange={handleInputChange}
        />
      </div>
      <div className="form-section">
        <label htmlFor="deathDate">Date of Death:</label>
        <input
          type="date"
          name="deathDate"
          id="deathDate"
          value={deathDate}
          onChange={handleInputChange}
        />
      </div>
      <button onClick={handleSearch} disabled={loading}>
        {loading ? 'Loading...' : 'Search'}
      </button>
    </div>
  );
};

export default CISLookup;
