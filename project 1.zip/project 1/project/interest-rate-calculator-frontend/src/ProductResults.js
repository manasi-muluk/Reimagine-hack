import React, { useState, useEffect } from 'react';
import { useLocation, useNavigate } from 'react-router-dom';
import { FaChevronDown, FaChevronUp } from 'react-icons/fa';


const ProductResults = () => {
    const location = useLocation();
    const navigate = useNavigate();

    // Get the results passed from the search page
    const { results } = location.state || {};

    // State for managing which accordion is expanded
    const [openIndex, setOpenIndex] = useState(null);

    // Redirect if the page is directly accessed or refreshed
    useEffect(() => {
        // If no results were passed, redirect to CIS Calculator page
        if (!results) {
            navigate('/cis-calculator', { replace: true });
        }
    }, [results, navigate]);

    // Toggle accordion item
    const toggleAccordion = (index) => {
        setOpenIndex(openIndex === index ? null : index);  // Collapse if the same index is clicked, expand if new index
    };

    // Function to go back to the previous page
    const handleBackButtonClick = () => {
        navigate('/cis-calculator');  // This will navigate to the CIS calculator page
    };

    return (
        <div className="page-container">
            <h2>Customer Product Holdings</h2>
            <div className="results-section">
                {results && results.length > 0 ? (
                    <div className="accordion">
                        {results.map((product, index) => (
                            <div key={index} className="accordion-item">
                                {/* Accordion Header */}
                                <div className="accordion-header" onClick={() => toggleAccordion(index)}>
                                    <div className="accordion-title">
                                        {/* Product name - line 1 */}
                                        <div>{product.name}</div>

                                        {/* Sort code + account number on left, balance/interest on right - line 2 */}
                                        <div className="accordion-subline">
                                            <div className="subline-left">
                                                {product.sortcode} {product.accountNumber}
                                            </div>
                                            <div className="subline-right">
                                                Balance: £{product.balance}   Interest: £{product.interestAmount}
                                            </div>
                                        </div>
                                    </div>
                                    <span>
                                        {openIndex === index ? <FaChevronUp /> : <FaChevronDown />}
                                    </span>

                                </div>


                                {/* Accordion Content - Show previous rates */}
                                {openIndex === index && (
                                    <div className="accordion-content">
                                        {product.interestRatesHistory && product.interestRatesHistory.length > 0 ? (
                                            <table>
                                                <thead>
                                                    <tr>
                                                        <th>Date</th>
                                                        <th>Interest Rate (%)</th>
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                    {product.interestRatesHistory.map((rate, i) => (
                                                        <tr key={i}>
                                                            <td>{rate.date}</td>
                                                            <td>{rate.interestRate} %</td>
                                                        </tr>
                                                    ))}
                                                </tbody>
                                            </table>
                                        ) : (
                                            <p>No interest rate history available.</p>
                                        )}
                                    </div>
                                )}
                            </div>
                        ))}
                    </div>
                ) : (
                    <p>No results found.</p>
                )}
            </div>

            {/* Back Button at the bottom of the page */}
            <button onClick={handleBackButtonClick} className="back-button">
                Back
            </button>
        </div>
    );
};

export default ProductResults;
