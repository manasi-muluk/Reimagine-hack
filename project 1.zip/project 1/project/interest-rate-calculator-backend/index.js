const express = require('express');
const bodyParser = require('body-parser');
const cors = require('cors');
const app = express();
const { parseISO, differenceInDays } = require('date-fns');

// Enable CORS for all origins
app.use(cors());

// Middleware
app.use(bodyParser.json());

// Mock data for products (updated with sortcode and accountNumber)
const mockProductData = {
    '4829305716': [
      {
        name: 'DMY1D-cadtes & BBA',
        balance: 2300.5,
        interestRate: 2.5,
        interestRatesHistory: [
          { date: '2023-06-01', interestRate: 2.3 },
          { date: '2023-06-15', interestRate: 2.4 },
          { date: '2023-07-01', interestRate: 2.5 }
        ],
        sortcode: '20-16-19',
        accountNumber: '12345678'
      },
      {
        name: 'Saver Flex',
        balance: 5125.0,
        interestRate: 3.0,
        interestRatesHistory: [
          { date: '2023-06-01', interestRate: 2.9 },
          { date: '2023-06-15', interestRate: 3.0 },
          { date: '2023-07-01', interestRate: 3.1 }
        ],
        sortcode: '30-40-50',
        accountNumber: '87654321'
      },
      {
        name: 'Business Deposit',
        balance: 300.0,
        interestRate: 1.2,
        interestRatesHistory: [
          { date: '2023-06-01', interestRate: 1.1 },
          { date: '2023-06-15', interestRate: 1.2 },
          { date: '2023-07-01', interestRate: 1.3 }
        ],
        sortcode: '50-60-70',
        accountNumber: '11223344'
      }
    ],
  
    '7602941835': [
      {
        name: 'Saver Flex',
        balance: 4200.0,
        interestRate: 2.2,
        interestRatesHistory: [
          { date: '2023-06-01', interestRate: 2.1 },
          { date: '2023-06-15', interestRate: 2.2 },
          { date: '2023-07-01', interestRate: 2.3 }
        ],
        sortcode: '11-22-33',
        accountNumber: '99887766'
      },
      {
        name: 'Junior ISA',
        balance: 1500.0,
        interestRate: 3.5,
        interestRatesHistory: [
          { date: '2023-06-01', interestRate: 3.3 },
          { date: '2023-06-15', interestRate: 3.4 },
          { date: '2023-07-01', interestRate: 3.5 }
        ],
        sortcode: '22-33-44',
        accountNumber: '88776655'
      },
      {
        name: 'Business Deposit',
        balance: 8000.0,
        interestRate: 1.8,
        interestRatesHistory: [
          { date: '2023-06-01', interestRate: 1.6 },
          { date: '2023-06-15', interestRate: 1.7 },
          { date: '2023-07-01', interestRate: 1.8 }
        ],
        sortcode: '44-55-66',
        accountNumber: '77665544'
      }
    ],
  
    '1938475620': [
      {
        name: 'Gold Saver',
        balance: 9000.0,
        interestRate: 2.7,
        interestRatesHistory: [
          { date: '2023-06-01', interestRate: 2.5 },
          { date: '2023-06-15', interestRate: 2.6 },
          { date: '2023-07-01', interestRate: 2.7 }
        ],
        sortcode: '12-34-56',
        accountNumber: '66554433'
      },
      {
        name: 'Child Trust Fund',
        balance: 1200.0,
        interestRate: 4.0,
        interestRatesHistory: [
          { date: '2023-06-01', interestRate: 3.8 },
          { date: '2023-06-15', interestRate: 3.9 },
          { date: '2023-07-01', interestRate: 4.0 }
        ],
        sortcode: '65-43-21',
        accountNumber: '55443322'
      },
      {
        name: 'Standard Saver',
        balance: 2200.0,
        interestRate: 2.0,
        interestRatesHistory: [
          { date: '2023-06-01', interestRate: 1.8 },
          { date: '2023-06-15', interestRate: 1.9 },
          { date: '2023-07-01', interestRate: 2.0 }
        ],
        sortcode: '78-90-12',
        accountNumber: '44332211'
      }
    ],
  };
  

//   function calculateInterestForPeriod(balance, rate, days) {
//     return (balance * rate * days) / (100 * 365);
//   }
  
//   // Helper to calculate interest with rate changes during period
//   function calculateInterestWithRateChanges(balance, currentRate, startDate, endDate, rateChanges) {
//     let totalInterest = 0;
//     let periodStart = parseISO(startDate);
//     const periodEnd = parseISO(endDate);
//     let rateToUse = currentRate;
  
//     // Sort rate changes ascending by date
//     rateChanges.sort((a, b) => compareAsc(parseISO(a.date), parseISO(b.date)));
  
//     for (const rateChange of rateChanges) {
//       const changeDate = parseISO(rateChange.date);
  
//       if (changeDate > periodEnd) break;
  
//       const days = differenceInDays(changeDate, periodStart);
//       if (days > 0) {
//         totalInterest += calculateInterestForPeriod(balance, rateToUse, days);
//       }
  
//       periodStart = changeDate;
//       rateToUse = rateChange.interestRate;
//     }
  
//     // Remaining days after last rate change
//     const remainingDays = differenceInDays(periodEnd, periodStart);
//     if (remainingDays > 0) {
//       totalInterest += calculateInterestForPeriod(balance, rateToUse, remainingDays);
//     }
  
//     return totalInterest.toFixed(2);
//   }
  

// Function to calculate interest based on the balance, interest rate, and number of days
function calculateInterestForPeriod(balance, rate, days) {
    return (balance * rate * days) / (100 * 365);  // Formula for simple interest
}

// Helper function to find the applicable interest rate on a given date
function getApplicableRate(dateOfDeath, interestRatesHistory) {
    // Sort interestRatesHistory in descending order of date
    const sortedHistory = interestRatesHistory.sort((a, b) => new Date(b.date) - new Date(a.date));

    // Find the most recent rate that applies on or before the dateOfDeath
    for (const entry of sortedHistory) {
        const rateChangeDate = parseISO(entry.date);
        if (rateChangeDate <= parseISO(dateOfDeath)) {
            return entry.interestRate;
        }
    }

    // If no applicable rate found, return 0 or handle this case as needed
    return 0;
}

// Route to handle CIS search and interest calculation
app.post('/search', (req, res) => {
    const { cisNumber, dateOfDeath } = req.body;

    if (!cisNumber || !dateOfDeath) {
        return res.status(400).json({ error: 'cisNumber and dateOfDeath are required' });
    }

    const products = mockProductData[cisNumber];

    if (!products) {
        return res.status(404).json({ error: 'CIS Number not found' });
    }

    const deathDate = parseISO(dateOfDeath);
    if (isNaN(deathDate)) {
        return res.status(400).json({ error: 'Invalid dateOfDeath format' });
    }

    // Loop through each product and calculate the interest
    const result = products.map(product => {
        const balance = product.balance;
        const interestRatesHistory = product.interestRatesHistory;

        // Find the interest rate applicable on the date of death
        const applicableRate = getApplicableRate(dateOfDeath, interestRatesHistory);

        // Calculate the days from the start of the month (or last day of previous month) to the date of death
        const firstDayOfMonth = new Date(deathDate.getFullYear(), deathDate.getMonth(), 1);
        const daysToCalculate = differenceInDays(deathDate, firstDayOfMonth);

        // Calculate the interest for that period
        const interestAmount = calculateInterestForPeriod(balance, applicableRate, daysToCalculate).toFixed(2);

        // Sort interestRatesHistory in descending order and slice last 3 entries
        const sortedHistory = [...interestRatesHistory].sort((a, b) => new Date(b.date) - new Date(a.date));

        return {
            ...product,
            interestAmount,
            interestRatesHistory: sortedHistory.slice(0, 3)
        };
    });

    res.json({ products: result });
});

const PORT = 5000;
app.listen(PORT, () => {
    console.log(`Server running on http://localhost:${PORT}`);
});
