package com.example.demo.config;

import org.springframework.cloud.contract.wiremock.WireMockConfigurationCustomizer;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Profile;

import com.github.tomakehurst.wiremock.core.WireMockConfiguration;
import org.springframework.cloud.contract.wiremock.WireMockSpring;

@Configuration
@Profile("dev")
public class WireMockConfig {

    @Bean
    public WireMockConfigurationCustomizer optionsCustomizer() {
        return config -> config.port(9090);
    }

    @Bean(initMethod = "start", destroyMethod = "stop")
    public com.github.tomakehurst.wiremock.WireMockServer wireMockServer() {
        WireMockConfiguration options = WireMockSpring.options().port(9090);
        com.github.tomakehurst.wiremock.WireMockServer wireMockServer = new com.github.tomakehurst.wiremock.WireMockServer(options);

        // Configure stubs
        wireMockServer.stubFor(com.github.tomakehurst.wiremock.client.WireMock.get("/customer/1234567890")
                .willReturn(com.github.tomakehurst.wiremock.client.WireMock.aResponse()
                        .withHeader("Content-Type", "application/json")
                        .withBodyFile("customer-products.json")
                        .withStatus(200)));

        wireMockServer.stubFor(com.github.tomakehurst.wiremock.client.WireMock.post("/products/interestRates")
                .willReturn(com.github.tomakehurst.wiremock.client.WireMock.aResponse()
                        .withHeader("Content-Type", "application/json")
                        .withBodyFile("interest-rates.json")
                        .withStatus(200)));

        wireMockServer.stubFor(com.github.tomakehurst.wiremock.client.WireMock.post("/products/historicalRates")
                .willReturn(com.github.tomakehurst.wiremock.client.WireMock.aResponse()
                        .withHeader("Content-Type", "application/json")
                        .withBodyFile("historical-rates.json")
                        .withStatus(200)));

        return wireMockServer;
    }
}
