package com.example.demo.beans;

import java.math.BigDecimal;
import java.util.List;

public class CustomerProductsResponse {
    private List<ProductBalance> products;

    public List<ProductBalance> getProducts() {
        return products;
    }

    public void setProducts(List<ProductBalance> products) {
        this.products = products;
    }

    // Getter and Setter
}


