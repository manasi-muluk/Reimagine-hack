package com.example.demo.beans;

import java.math.BigDecimal;
import java.util.List;
import java.util.Map;

// HistoricalRatesResponse.java
public class HistoricalRatesResponse {
    private Map<String, List<RateChange>> historicalRates;

    // Getters and setters
    public Map<String, List<RateChange>> getHistoricalRates() {
        return historicalRates;
    }

    public void setHistoricalRates(Map<String, List<RateChange>> historicalRates) {
        this.historicalRates = historicalRates;
    }

    // Inner RateChange class
    public static class RateChange {
        private String date;
        private double rate;

        // Getters and setters
        public String getDate() {
            return date;
        }

        public void setDate(String date) {
            this.date = date;
        }

        public double getRate() {
            return rate;
        }

        public void setRate(double rate) {
            this.rate = rate;
        }
    }
}

