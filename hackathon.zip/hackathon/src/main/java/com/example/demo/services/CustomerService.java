package com.example.demo.services;


import com.example.demo.beans.*;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;
import org.springframework.beans.factory.annotation.Autowired;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.temporal.ChronoUnit;
import java.util.*;
import java.util.stream.Collectors;

@Service
public class CustomerService {

    private final RestTemplate restTemplate;

    @Autowired
    public CustomerService(RestTemplate restTemplate) {
        this.restTemplate = restTemplate;
    }

    public CustomerResponse calculateTotalAmount(CustomerRequest request) {
        // Call the WireMock endpoints (mocked external APIs)
        String customerApiUrl = "http://localhost:9090/customer/" + request.getCis();
        CustomerProductsResponse customerProducts = restTemplate.getForObject(customerApiUrl, CustomerProductsResponse.class);

        // Call the Interest Rates API (WireMock mock)
        String interestRatesApiUrl = "http://localhost:9090/products/interestRates";
        InterestRatesResponse interestRates = restTemplate.postForObject(interestRatesApiUrl, customerProducts.getProducts(), InterestRatesResponse.class);

        // Call the Historical Interest Rates API (WireMock mock)
        String historicalRatesApiUrl = "http://localhost:9090/products/historicalRates";
        HistoricalRatesResponse historicalRates = restTemplate.postForObject(historicalRatesApiUrl, customerProducts.getProducts(), HistoricalRatesResponse.class);

        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");
        LocalDate dateOfDeath = LocalDate.parse(request.getDod(), formatter);


        // Calculate interest amounts with product details
        Map<String, Object> result = calculateAmount(customerProducts, interestRates, historicalRates, dateOfDeath);

        // Extract values from result
        BigDecimal totalInterest = (BigDecimal) result.get("totalInterest");
        @SuppressWarnings("unchecked")
        List<CustomerResponse.ProductInterest> productInterestDetails =
                (List<CustomerResponse.ProductInterest>) result.get("productDetails");

        // Create response with total interest and product details
        return new CustomerResponse(totalInterest, productInterestDetails);
    }

    private Map<String, Object> calculateAmount(CustomerProductsResponse customerProducts,
                                                InterestRatesResponse interestRates,
                                                HistoricalRatesResponse historicalRates,
                                                LocalDate dateOfDeath) {

        // Dynamically calculate the last day of the previous month
        LocalDate lastDayPreviousMonth = dateOfDeath.withDayOfMonth(1).minusDays(1);

        // Calculate days for which interest needs to be calculated
        long daysToCalculate = ChronoUnit.DAYS.between(lastDayPreviousMonth, dateOfDeath);

        BigDecimal totalInterest = BigDecimal.ZERO;
        List<CustomerResponse.ProductInterest> productInterestDetails = new ArrayList<>();

        // Process each product
        for (ProductBalance product : customerProducts.getProducts()) {
            String productId = product.getProductId();
            BigDecimal balance = BigDecimal.valueOf(product.getBalance());

            // Get current interest rate for the product
            Double currentRateObj = interestRates.getProductInterestRates().get(productId);
            if (currentRateObj == null) {
                // Skip if no interest rate is defined for this product
                continue;
            }
            double currentRate = currentRateObj;

            // Check if there was a rate change during the period
            List<HistoricalRatesResponse.RateChange> rateChanges = getRelevantRateChanges(
                    historicalRates.getHistoricalRates().get(productId),
                    lastDayPreviousMonth,
                    dateOfDeath
            );

            // Calculate interest based on rate changes
            BigDecimal productInterest;
            if (rateChanges.isEmpty()) {
                // No rate changes during the period, use current rate for all days
                productInterest = calculateInterestForPeriod(balance, currentRate, daysToCalculate);
            } else {
                // Handle rate changes during the period
                productInterest = calculateInterestWithRateChanges(
                        balance, currentRate, lastDayPreviousMonth, dateOfDeath, rateChanges);
            }

            // Add to total interest
            totalInterest = totalInterest.add(productInterest);

            // Add product interest details
            productInterestDetails.add(new CustomerResponse.ProductInterest(
                    productId, balance, productInterest));
        }

        // Return both total interest and product details
        Map<String, Object> result = new HashMap<>();
        result.put("totalInterest", totalInterest);
        result.put("productDetails", productInterestDetails);

        return result;
    }

    // Helper method to calculate interest for a period with no rate changes
    private BigDecimal calculateInterestForPeriod(BigDecimal balance, double rate, long days) {
        // Daily interest formula: balance * (rate / 365) * days
        BigDecimal dailyRate = BigDecimal.valueOf(rate)
                .divide(BigDecimal.valueOf(365), 10, RoundingMode.HALF_UP);

        return balance.multiply(dailyRate)
                .multiply(BigDecimal.valueOf(days))
                .setScale(2, RoundingMode.HALF_UP);
    }

    // Helper method to calculate interest with rate changes
    private BigDecimal calculateInterestWithRateChanges(
            BigDecimal balance,
            double currentRate,
            LocalDate startDate,
            LocalDate endDate,
            List<HistoricalRatesResponse.RateChange> rateChanges) {

        BigDecimal totalInterest = BigDecimal.ZERO;
        LocalDate periodStart = startDate;
        double rateToUse = currentRate;

        // Sort rate changes by date
        rateChanges.sort(Comparator.comparing(rc -> LocalDate.parse(rc.getDate())));

        // Calculate interest for each sub-period with different rates
        for (HistoricalRatesResponse.RateChange rateChange : rateChanges) {
            LocalDate changeDate = LocalDate.parse(rateChange.getDate());

            // Calculate days until rate change
            long daysInPeriod = ChronoUnit.DAYS.between(periodStart, changeDate);

            // Add interest for this sub-period
            if (daysInPeriod > 0) {
                totalInterest = totalInterest.add(
                        calculateInterestForPeriod(balance, rateToUse, daysInPeriod));
            }

            // Update for next period
            periodStart = changeDate;
            rateToUse = rateChange.getRate();
        }

        // Calculate interest for the final sub-period (after last rate change to end date)
        long remainingDays = ChronoUnit.DAYS.between(periodStart, endDate);
        if (remainingDays > 0) {
            totalInterest = totalInterest.add(
                    calculateInterestForPeriod(balance, rateToUse, remainingDays));
        }

        return totalInterest.setScale(2, RoundingMode.HALF_UP);
    }

    // Helper method to filter relevant rate changes within the period
    private List<HistoricalRatesResponse.RateChange> getRelevantRateChanges(
            List<HistoricalRatesResponse.RateChange> allRateChanges,
            LocalDate startDate,
            LocalDate endDate) {

        if (allRateChanges == null) {
            return Collections.emptyList();
        }

        return allRateChanges.stream()
                .filter(rc -> {
                    LocalDate changeDate = LocalDate.parse(rc.getDate());
                    return !changeDate.isBefore(startDate) && !changeDate.isAfter(endDate);
                })
                .collect(Collectors.toList());
    }
}


