package com.example.demo.beans;

import java.math.BigDecimal;
import java.util.Map;

public class InterestRatesResponse {
    private Map<String, Double> productInterestRates;

    // Getters and setters
    public Map<String, Double> getProductInterestRates() {
        return productInterestRates;
    }

    public void setProductInterestRates(Map<String, Double> productInterestRates) {
        this.productInterestRates = productInterestRates;
    }
}

