package com.example.demo.beans;

import java.math.BigDecimal;
import java.util.List;

public class CustomerResponse {
    private BigDecimal totalInterestAmount;
    private List<ProductInterest> productInterestDetails;

    public CustomerResponse(BigDecimal totalInterestAmount, List<ProductInterest> productInterestDetails) {
        this.totalInterestAmount = totalInterestAmount;
        this.productInterestDetails = productInterestDetails;
    }

    // Getters and setters
    public BigDecimal getTotalInterestAmount() {
        return totalInterestAmount;
    }

    public void setTotalInterestAmount(BigDecimal totalInterestAmount) {
        this.totalInterestAmount = totalInterestAmount;
    }

    public List<ProductInterest> getProductInterestDetails() {
        return productInterestDetails;
    }

    public void setProductInterestDetails(List<ProductInterest> productInterestDetails) {
        this.productInterestDetails = productInterestDetails;
    }

    // Inner class for product interest details
    public static class ProductInterest {
        private String productId;
        private BigDecimal balance;
        private BigDecimal interestAmount;

        public ProductInterest(String productId, BigDecimal balance, BigDecimal interestAmount) {
            this.productId = productId;
            this.balance = balance;
            this.interestAmount = interestAmount;
        }

        // Getters and setters
        public String getProductId() {
            return productId;
        }

        public void setProductId(String productId) {
            this.productId = productId;
        }

        public BigDecimal getBalance() {
            return balance;
        }

        public void setBalance(BigDecimal balance) {
            this.balance = balance;
        }

        public BigDecimal getInterestAmount() {
            return interestAmount;
        }

        public void setInterestAmount(BigDecimal interestAmount) {
            this.interestAmount = interestAmount;
        }
    }
}

