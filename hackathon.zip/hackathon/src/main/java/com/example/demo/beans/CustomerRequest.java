package com.example.demo.beans;

import java.time.LocalDate;

public class CustomerRequest {

    private String cis;
    private String dod;
    private String dateRangeFrom;
    private String dateRangeTo;
    private boolean historicalBalance;

    // Getters and Setters
    public String getCis() {
        return cis;
    }

    public void setCis(String cis) {
        this.cis = cis;
    }

    public String getDod() {
        return dod;
    }

    public void setDod(String dod) {
        this.dod = dod;
    }

    public String getDateRangeFrom() {
        return dateRangeFrom;
    }

    public void setDateRangeFrom(String dateRangeFrom) {
        this.dateRangeFrom = dateRangeFrom;
    }

    public String getDateRangeTo() {
        return dateRangeTo;
    }

    public void setDateRangeTo(String dateRangeTo) {
        this.dateRangeTo = dateRangeTo;
    }

    public boolean isHistoricalBalance() {
        return historicalBalance;
    }

    public void setHistoricalBalance(boolean historicalBalance) {
        this.historicalBalance = historicalBalance;
    }
}

