package com.example.demo.beans;

import java.math.BigDecimal;

public class ProductBalance {
    private String productId;
    private long balance;

    // Getter and Setter

    public String getProductId() {
        return productId;
    }

    public void setProductId(String productId) {
        this.productId = productId;
    }

    public long getBalance() {
        return balance;
    }

    public void setBalance(long balance) {
        this.balance = balance;
    }
}
