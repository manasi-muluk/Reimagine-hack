package com.example.demo.controller;

import com.example.demo.beans.CustomerRequest;
import com.example.demo.beans.CustomerResponse;
import com.example.demo.services.CustomerService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api")
public class CustomerController {

    @Autowired
    private final CustomerService customerService;

    // Injecting CustomerService to handle business logic
    public CustomerController(CustomerService customerService) {
        this.customerService = customerService;
    }

    @PostMapping("/searchCustomer")
    public CustomerResponse searchCustomer(@RequestBody CustomerRequest customerRequest) {
        return customerService.calculateTotalAmount(customerRequest);
    }
}

